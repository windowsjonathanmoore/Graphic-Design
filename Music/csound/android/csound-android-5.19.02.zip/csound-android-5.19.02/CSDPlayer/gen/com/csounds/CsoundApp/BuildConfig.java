/** Automatically generated file. DO NOT MODIFY */
package com.csounds.CsoundApp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}