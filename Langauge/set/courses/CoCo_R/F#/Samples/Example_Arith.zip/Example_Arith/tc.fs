open System;
open System.IO;
open System.Collections.Generic

type dados = 
class
      //vari�veis
        val mutable operador : int;
       val mutable valor:string;
        //construtores
        
       
        new()= {operador =0; valor = null}
        new((op:int),(vl:string)) ={ operador = op; valor = vl;  }
         
        //m�todos
        member x.setDados((o:int), (v:string)) = x.operador <-o; x.valor <- v; 
        member x.getOperador() = x.operador; 
        member x.getValor() = x.valor; 
		
		//new()={operador}

        member x.Clone(ob:dados)=
            let teste = new dados() in
            teste.operador <- ob.operador;
            teste.valor <- ob.valor;
            teste;
       
    end //class dados

    type Objectos=
    class
       //vari�veis
        val  mutable nome: string
        val mutable   tipo:int //0-undef, 1-integer, 2-real -- como est� definido no ATG
        val  mutable  valorI:int
        val mutable  valorF:float;
        //construtores
        new()={nome = ""; tipo = 0; valorF = 0.0; valorI = 0;}
        new((n:string ),  (t:int))={ nome = n; tipo = t; valorF = 0.0; valorI = 0; }
      
        //m�todos
        member x.comparaNome(nomeVar:string ) = (x.nome.Equals(nomeVar)); 
        member x.setObjectosNome(name:string ) = x.nome <- name; 
        member x.setObjectosTipo(tp:int ) = x.tipo <- tp; 
        member x.setObjectosFloat( f:float) = x.valorF <- f; 
        member x.setObjectosInt( i:int) = x.valorI <- i; 
        member x.getObjectosTipo() = x.tipo; 
        member x.getObjectosNome() =  x.nome; 
        member x.getObjectosValorI() =  x.valorI; 
        member x.getObjectosValorF() = x.valorF; 

        member x.Clone(ob:Objectos)=
            let teste = new Objectos() in
            teste.nome <- ob.nome;
            teste.tipo <- ob.tipo;
            teste.valorI <- ob.valorI;
            teste.valorF <- ob.valorF;
            teste;
        
    end//class Objectos


type Op =  ADD | SUB | MUL | DIV |   FMUL | FADD |  FSUB |  FDIV |  WRITEI |  WRITEF |  POP 
	   |START |  ERR | STOP | STOREG| STOREL| DUP| PUSHI| PUSHF| PUSHG |  PUSHL |  PUSHN 
	  
let returnOp num =
	match num with
	   |0->ADD
	   |1->SUB
	   |2->MUL
	   |3->DIV
	   |4->FMUL
	   |5->FADD
	   |6->FSUB 
	   |7->FDIV 
	   |8->WRITEI 
	   |9->WRITEF 
	   |10->POP 
	   |11->START 
	   |12->ERR
	   |13->STOP
	   |14->STOREG
	   |15->STOREL
	   |16->DUP
	   |17->PUSHI
	   |18->PUSHF
	   |19->PUSHG
	   |20->PUSHL
	   |21->PUSHN
	   |_ -> ERR


type TC=
class
        val mutable contador :int 
           val mutable cont :int 
        val mutable locais:int 
        val mutable globais:int
	  val mutable aimprimir : dados array;
      val mutable aObjectosGlobais : Objectos array;
      val mutable aObjectosLocais : Objectos array;
	  
	  
	  new()={
	   contador =3;
	   cont=0; 
       locais=0; 
       globais=0;
       aimprimir = Array.zero_create 3 ;
       aObjectosGlobais = (Array.zero_create 1) ;
       aObjectosLocais = Array.zero_create 1;
       }


        member x.setLocais() = x.locais = x.aObjectosGlobais.Length; //x.aObjectosGlobais.Length; 
        member x.setGlobais() = x.globais = x.globais + 1; 
        member x.getLocais() = x.locais; 
        member x.getGlobais() = x.globais; 


       member x.opcode =  [|"ADD  "; "SUB  "; "MUL  "; "DIV  "; "FMUL "; "WRITEI"; "WRITEF";
        "FMUL"; "ERR" |];

  
        //public static dados[] aimprimir = new dados[1000];



		member x.setObjectosLocais(al:Objectos)= 
		//x.aObjectosLocais.(x.locais)<-al;
		//x.locais<-x.locais+1;
			let t = ref x.aObjectosLocais in
		Array.Resize(t, x.locais+1);
		x.aObjectosLocais<- !t;
		
		x.aObjectosLocais.(x.locais) <- al;
		x.locais<-x.locais+1;
		x.cont<-x.locais;
		
		
		member x.setObjectosGlobais(al:Objectos)= 
			let t = ref x.aObjectosGlobais in
			Array.Resize(t, x.globais+1);
			x.aObjectosGlobais<- !t;
			x.aObjectosGlobais.(x.globais) <- al;
			x.globais<-x.globais+1;
	
		
		
		
        //----- code generation methods -----

        //devolve a posicao da variavel 'nomeVar' na lista 'al', caso exista,
        //caso n�o exista devolve -1
        member x.getObjIndex((al:Objectos array), (nomeVar:string))=
        let b = ref (new Objectos()) and mutable final=(-1) in
        let n = ref 0 and control = ref (-1) in 
        try
          let a=  Array.FindLastIndex(al, fun (l:Objectos) -> if(l.nome = nomeVar) then 
													(true) else ( false)) in a
           with _ -> -1
         
        

        //devolve o tipo da variavel 'nomeVar' na lista 'al', caso exista,
        //caso n�o exista devolve -1
        member x.getObjTipo((al:Objectos array), (nomeVar:string))=
              try
				let bc = Array.FindLast(al, fun (l:Objectos) -> if(l.nome = nomeVar ) then 
													( true) else (false)) in
            
	            if (bc <> new Objectos()) then (bc.getObjectosTipo();)
		        else (-1);
        with _ -> -1

        
        //devolve o valor inteiro da variavel que est� na posi�ao 'indice' na lista 'al'
        member x.getObjValorI((al:Objectos array), (indice:int))=
		((al.(indice)).getObjectosValorI());
        

        //devolve o valor real da variavel que est� na posi�ao 'indice' na lista 'al'
        member x.getObjValorF((al:Objectos array), (indice:int))=
       ((al.(indice)).getObjectosValorF());
      


        member x.setImprimir((op:int), (v:string ), (conta:int))=
            if (x.contador = 0)
            then(
                x.aimprimir.(x.contador) <-  new dados();
                x.aimprimir.(x.contador+1) <-  new dados();
                x.aimprimir.(x.contador+2)<- new dados();
            );

			let d = new dados() in(*and c = ref(new dados()) in*)
				d.setDados(op, v);
				//c:=d;
				x.contador <- x.contador + 1;
	        
			let t = ref x.aimprimir in
					Array.Resize(t, x.contador);
					x.aimprimir<- !t;
					x.aimprimir.(conta) <- d;



        member x.Compiler((data:string))=
        let operacao=ref 0 and n= ref "" and nome_ficheiro = data^".vm" and dd = new dados() in
            try
            (
                           //Verificar arrays
              
                for i = 0 to x.contador do
                    if (x.aimprimir.(i) <> new dados())
                    then(
                        try
                        
                            dd.setDados((x.aimprimir.(i)).getOperador(), (x.aimprimir.(i)).getValor());
                        
						
                        operacao := dd.getOperador();

                        //n = Convert.ToInt32(dd.getValor()); 
                        
                        if (dd.getValor() <> "") then  ( 
                       
                        n := dd.getValor().ToString();
          
                        );
						
						
                        match returnOp !operacao with
                            
                                |PUSHI -> File.AppendAllText(nome_ficheiro, "\tpushi " + !n + "\n"); 
                                |PUSHF -> File.AppendAllText(nome_ficheiro, "\tpushf " + !n + "\n");  //vari�veis locais
                                |PUSHG -> File.AppendAllText(nome_ficheiro, "\tpushg " + !n + "\n");   //vari�veis globais
                                |PUSHL -> File.AppendAllText(nome_ficheiro, "\tpushl " + !n + "\n"); 
                                |STOREG -> File.AppendAllText(nome_ficheiro, "\tstoreg " + !n + "\n"); 
                                |STOREL -> File.AppendAllText(nome_ficheiro, "\tstorel " + !n + "\n"); 
                                |DUP -> File.AppendAllText(nome_ficheiro, "\tdup " + !n + "\n"); 
                                |POP -> File.AppendAllText(nome_ficheiro, "\tpop " + !n + "\n"); 
                                |START -> File.AppendAllText(nome_ficheiro, "\tstart\n"); 
                                |ADD -> File.AppendAllText(nome_ficheiro, "\tadd\n");    //soma
                                |SUB -> File.AppendAllText(nome_ficheiro, "\tsub\n");   //subtrac��o
                                |DIV -> File.AppendAllText(nome_ficheiro, "\tdiv\n");  //divis�o
                                |MUL -> File.AppendAllText(nome_ficheiro, "\tmul\n");  //multiplica��o
                                |FADD -> File.AppendAllText(nome_ficheiro, "\tfadd\n");    //soma
                                |FSUB -> File.AppendAllText(nome_ficheiro, "\tfsub\n");   //subtrac��o
                                |FDIV -> File.AppendAllText(nome_ficheiro, "\tfdiv\n");  //divis�o
                                |FMUL -> File.AppendAllText(nome_ficheiro, "\tfmul\n");  //multiplica��o
                                |WRITEI-> File.AppendAllText(nome_ficheiro, "\twritei\n"); 
                                |WRITEF-> File.AppendAllText(nome_ficheiro, "\twritef\n"); 
                                |PUSHN-> File.AppendAllText(nome_ficheiro, "\tpushn " + !n + "\n"); 
                                |ERR-> printf "Erro encontrado\n";
                                |STOP-> File.AppendAllText(nome_ficheiro, "\tstop\n"); 
                                

                        with _ ->
							(
                            printf "#({0}) Erro na obten��o dos dados.\n";
                            System.Environment.Exit(0);
							)
)
                       
                  done;
            )


            with _ ->
            (
                Console.WriteLine("--- Erro ao aceder ao ficheiro {0}", data);
                System.Environment.Exit(0);
            )
        


        
    end // end TC

