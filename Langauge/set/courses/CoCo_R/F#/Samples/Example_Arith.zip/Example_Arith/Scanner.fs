

open System
open System.IO;
open System.Collections.Generic;


let post_dec r = 
  let v = r-1 in v

let post_inc r = 
  let v = r+1 in v

type Token = 
	class
		val kind : int			//token kind 
		val pos : int			//token position in the source text (starting at 0)
		val col : int			//token column (starting at 1)
		val line : int			//token line (strating at 1)
		val value : String		//token value
		val mutable next : Token option //ML 2005-03-11 Tokens are kept in a linked list

		new (k, p, c, l, v, n) = {kind = k; pos = p; col = c; line = l; value = v; next = n};
end

exception Result of string*int


//Para a leitura do ficheiro, esta será uma função externa

type Buffer = 
	class
	val EOF : int
	val MAX_BUFFER_LENGTH : int 
	val mutable utf : bool
	val mutable pos : int
	val mutable stream : in_channel
	val mutable isUserStream : bool

	new() = {
		EOF = (Char.code Char.MaxValue) + 1;
		MAX_BUFFER_LENGTH = 64 * 1024;
		utf = false;
		pos = 0;
		stream = stdin;
		isUserStream = false;
	}

	member x.Read()= 
		let ch = ref 0 in
			if (not x.utf) then
				ch := input_byte x.stream
			else(
				ch := input_byte x.stream;
		
			while((!ch >= 128) && ((!ch &&& 0xC0) <> 0xC0) && (!ch <> x.EOF)) do
				ch:= input_byte x.stream;
			done;

			if (!ch >= 128 || !ch <>  x.EOF) then (*If char is minor to 128 or equals to EOF then ther's nothing to do*)
				// nothing to do, first 127 chars are the same in ascii and utf8
				// 0xxxxxxx or end of file character
			if ((!ch &&& 0xF0) = 0xF0) then
				// 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
				let c1 = !ch &&& 0x07 in ch :=  input_byte x.stream;
				let c2 = !ch &&& 0x3F in ch :=  input_byte x.stream;
				let c3 = !ch &&& 0x3F in ch :=  input_byte x.stream;
				let c4 = !ch &&& 0x3F in
				ch := (((((c1 <<< 6) ||| c2) <<< 6) ||| c3) <<< 6) ||| c4;
			else if ((!ch &&& 0xE0) = 0xE0) then
				// 1110xxxx 10xxxxxx 10xxxxxx
				let c1 = !ch &&& 0x0F in ch :=  input_byte x.stream;
				let c2 = !ch &&& 0x3F in ch :=  input_byte x.stream;
				let c3 = !ch &&& 0x3F in
				ch := (((c1 <<< 6) ||| c2) <<< 6) ||| c3;
			else if ((!ch &&& 0xC0) = 0xC0) then (
				// 110xxxxx 10xxxxxx
				let c1 = !ch &&& 0x1F in ch :=  input_byte x.stream;
				let c2 = !ch &&& 0x3F in
				ch := (c1 <<< 6) ||| c2;
				);
			);
			Char.chr !ch

	member x.Peek_in() =
			let pos = pos_in x.stream in
			let chr = x.Read() in seek_in x.stream (pos-1); chr
end 




type scanner=
	class
	val mutable buffer : Buffer
	val EOL : char
	val mutable maxT : int
	val mutable noSym : int
	val charSetSize : int
	val eofSym : int 
	val mutable t : Token //current token
	val mutable ch : int
	val mutable col : int
	val mutable line : int
	val mutable oldEols : int

	val mutable tval : Buffer.t

	val mutable start : Dictionary<int, int>

	val mutable tokens : Token
	val mutable pt : Token

	val mutable tlen : int
	val Impossible : System.Exception

	val mutable lineStart : int

	new () = {
		buffer = new Buffer();
		EOL = '\n'; 
		eofSym = 0;
		charSetSize = 256;
		maxT = 16;
		noSym = 16;
		t = new Token (0,0,0,0,"dummy",None); //{kind = 0; pos = 0; col = 0; line = 0; value = "dummy"; next = None};
		ch = Char.code '\n'; //starts the current character with the value os new line
		col = 0;
		line = 1;
		oldEols = 0;
		lineStart = 0;
		tval = Buffer.create 1;
		Impossible = new System.Exception();
		tokens = new Token (0,0,0,0,"dummy",None);
		pt = new Token (0,0,0,0,"dummy",None);
		start =  new Dictionary<int, int>(128);
		tlen = 0;
		}

	member x.Scanner(filename:string) =
		try
			x.buffer.stream <- open_in (filename);
			x.Initiation();
		with _ -> (fprintf stdout "Impossible of open file"; exit 1;);  

	
	member x.Scanner2(s: in_channel) =
		try
			x.buffer.stream <- s;
			x.Initiation();
		with _ -> (fprintf stdout "Impossible of open file"; exit 1;);  
			  printf "Finish"



	member x.Initiation() =
		for i = 65 to 90 do 		x.start.Add(i,1); done;
		for i = 97 to 122 do 		x.start.Add(i,1); done;
		for i = 48 to 57 do 		x.start.Add(i,14); done;
		x.start.Add(59,6); 
		x.start.Add(43,7); 
		x.start.Add(45,8); 
		x.start.Add(42,9); 
		x.start.Add(47,10); 
		x.start.Add(61,11); 
		x.start.Add(40,12); 
		x.start.Add(41,13); 
		x.start.Add(65535+1, -1);
		for i = 0 to x.buffer.EOF-2 do 
			if x.start.ContainsKey(i)=false then x.start.Add(i,0); 
		done;

		x.NextCh();
		if (x.ch = 0xEF)
		then(  // check optional byte order mark for UTF-8
			x.NextCh();
			let ch1 = x.ch in
			x.NextCh(); 
			let ch2 = x.ch in
			if (ch1 <> 0xBB || ch2 <> 0xBF) then(
					raise (new Exception (String.Format("illegal byte order mark: EF {0,2:X} {1,2:X}", ch1, ch2)));
			)
			else (
				x.buffer.utf <- true;
				x.buffer.pos <- 2;
				x.col <- 0;
				x.NextCh();
			)
		)
		else (x.buffer.utf <- false; x.col <- 0; x.buffer.pos <- 0;);


	member x.AddCh() = 
		ignore (x.tval.Append(Char.chr x.ch));		x.NextCh()

	member x.NextCh() =
		if x.oldEols > 0 then ( x.ch <- Char.code x.EOL; x.oldEols <- post_dec x.oldEols)
		else ( x.ch <- Char.code(x.buffer.Read()); 
			x.buffer.pos <- post_inc x.buffer.pos;
	        if x.ch = Char.code x.EOL then (x.line <- post_inc x.line; x.lineStart <- x.buffer.pos + 1))
				
	
	member x.Comment0() =
		let level = ref 1 and line0 = x.line and lineStart0 = x.lineStart and more = ref true and result = ref false in
		x.NextCh();
		if (x.ch = Char.code '/') 
		then (
			x.NextCh();
			 try 
				 while !more do 
					 if (x.ch = 10) 
					 then ( 
						 level := post_dec !level;
						 if !level = 0 then( 
							 x.oldEols <- x.line - line0;  
							 x.NextCh(); 
							 result := true; 
							 more:= false )
				) else x.NextCh();
				 done;
				 !result;
			with
				End_of_file -> false )
		 else (
			if x.ch = Char.code x.EOL then (
			 level := post_dec !level;
			x.lineStart <- lineStart0 );
			 x.buffer.pos <- x.buffer.pos - 2;
			  seek_in (x.buffer.stream) (x.buffer.pos+1);
			 x.NextCh();
			 false )
	

	member x.Comment1() =
		let level = ref 1 and line0 = x.line and lineStart0 = x.lineStart and more = ref true and result = ref false in
		x.NextCh();
		if (x.ch = Char.code '*') 
		then (
			x.NextCh();
			 try 
				 while !more do 
					 if (x.ch = Char.code '*') 
					 then ( 
					x.NextCh();
					if (x.ch = Char.code ')') then (
						 level := post_dec !level;
						 if !level = 0 then( 
							 x.oldEols <- x.line - line0;  
							 x.NextCh(); 
							 result := true; 
							 more:= false )
					else x.NextCh();
					)
					 ) else if (x.ch = Char.code '(') then (
					x.NextCh();
					if (x.ch = Char.code '*') then (
						 level := post_inc !level; x.NextCh();
					)
				) else x.NextCh();
				 done;
				 !result;
			with
				End_of_file -> false )
		 else (
			if x.ch = Char.code x.EOL then (
			 level := post_dec !level;
			x.lineStart <- lineStart0 );
			 x.buffer.pos <- x.buffer.pos - 2;
			  seek_in (x.buffer.stream) (x.buffer.pos+1);
			 x.NextCh();
			 false )
	



	member x.checkLiteral (lit:string) def=
			match lit with

			| "set" -> 4 

			| "let" -> 5 

			| "in" -> 6 

			| "print" -> 7 

			| _ -> def 


	member x.resolveKind(value:int) = 
		match value with
	      -1 -> x.eofSym
	    |  0 -> x.noSym
		| 1 -> 
				if ((x.ch >= Char.code '0' && x.ch <= Char.code '9' || x.ch >= Char.code 'A' && x.ch <= Char.code 'Z' || x.ch >= Char.code 'a' && x.ch <= Char.code 'z')) then (x.AddCh(); x.resolveKind 1;)
				else (x.checkLiteral (Buffer.contents x.tval)  1 )
		| 2 -> 
				if ((x.ch >= Char.code '0' && x.ch <= Char.code '9')) then (x.AddCh(); x.resolveKind 2;)
				else if (x.ch = Char.code 'E') then (x.AddCh(); x.resolveKind 3;)
				else ( 3 )
		| 3 -> 
				if ((x.ch >= Char.code '0' && x.ch <= Char.code '9')) then (x.AddCh(); x.resolveKind 5;)
				else if ((x.ch = Char.code '+' || x.ch = Char.code '-')) then (x.AddCh(); x.resolveKind 4;)
				else ( x.noSym )
		| 4 -> 
				if ((x.ch >= Char.code '0' && x.ch <= Char.code '9')) then (x.AddCh(); x.resolveKind 5;)
				else ( x.noSym )
		| 5 -> 
				if ((x.ch >= Char.code '0' && x.ch <= Char.code '9')) then (x.AddCh(); x.resolveKind 5;)
				else ( 3 )
		| 6 -> 
				( 8 )
		| 7 -> 
				( 9 )
		| 8 -> 
				( 10 )
		| 9 -> 
				( 11 )
		| 10 -> 
				( 12 )
		| 11 -> 
				( 13 )
		| 12 -> 
				( 14 )
		| 13 -> 
				( 15 )
		| 14 -> 
				if ((x.ch >= Char.code '0' && x.ch <= Char.code '9')) then (x.AddCh(); x.resolveKind 14;)
				else if (x.ch = Char.code '.') then (x.AddCh(); x.resolveKind 2;)
				else ( 2 )
	    | _ -> raise (new Exception("resolveKind unknown kind"))


	member x.NextToken() = 
		try
			try
				while x.ch = Char.code ' ' ||  x.ch >= 9 && x.ch <= 10 || x.ch = 13 do  x.NextCh() done;
					if (x.ch = Char.code '/' && x.Comment0() || x.ch = Char.code '(' && x.Comment1()) then x.NextToken() else
					let _pos = x.buffer.pos and _col = x.buffer.pos - x.lineStart + 1 and _line = x.line and ccode= x.ch in
					Buffer.reset x.tval;
					x.AddCh();
				try
					let kind = x.resolveKind (x.start.Item(ccode)) in
					let t = new Token(kind,_pos,_col,_line,Buffer.contents x.tval,None) in t
				with
					Result (value,kind) -> let t = new Token(kind,_pos,_col,_line,value,None) in t
			with
				End_of_file -> let t = new Token(x.eofSym,x.buffer.pos,x.buffer.pos-x.lineStart+1,x.line,"",None) in t
		with _ -> (fprintf stdout "Char not recognized at line %d" x.line; exit 1;);

	member x.Extract_token t =
		match t with 
		  None -> raise (new Exception("Impossible extract_token")) 
		| Some c -> c
		
		
	member x.Scan() =
		if x.tokens.next = None
		then x.NextToken()
		else 
			(
				x.pt <- x.Extract_token x.tokens.next;
				x.tokens <- x.Extract_token x.tokens.next;
				x.tokens;
			)
			

	member x.Peek() =
		if x.pt.next = None 
		then (  
				x.pt <- x.NextToken(); 
				x.pt.next <- (Some x.pt);
				if x.pt.kind <= x.maxT then x.pt else x.Peek()
			)
		else (x.pt <- x.Extract_token x.pt.next; 
						if x.pt.kind <= x.maxT 
						then x.pt else x.Peek ()
			)
			
end
 
