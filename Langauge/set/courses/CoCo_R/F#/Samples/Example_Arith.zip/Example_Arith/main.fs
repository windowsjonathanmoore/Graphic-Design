open System
open System.IO;
open System.Collections.Generic;
open Scanner;
open Parser;
open Tc;


let ss = new scanner() in
	printf "File name\n";

let nomeficheiro = read_line() in
	printf "SCANNING\n";
	ss.Scanner(nomeficheiro); 
  
let pp = new parser(ss) in
	printf "PARSING\n";
	pp.Parse();
	printf "COMPILING\n";
	
let bc = ref (new Tc.Objectos()) in
	pp.tc.Compiler(nomeficheiro);

printf "END\n";