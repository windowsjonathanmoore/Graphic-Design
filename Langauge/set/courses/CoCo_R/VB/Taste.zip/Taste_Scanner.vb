Option Compare Binary
Option Explicit On
Option Strict On

Imports System
Imports System.Collections
Imports System.IO

Namespace Taste

	Public Class Token
		Public kind   As Integer ' token kind
		Public pos    As Integer ' token position in the source text (starting at 0)
		Public col    As Integer ' token column (starting at 1)
		Public line   As Integer ' token line (starting at 1)
		Public val    As String  ' token value
		Public [next] As Token   ' ML 2005-03-11 Tokens are kept in linked list
	End Class

	Public Class Buffer
		' This Buffer supports the following cases:
		' 1) seekable stream (file)
		'    a) whole stream in buffer
		'    b) part of stream in buffer
		' 2) non seekable stream (network, console)
		Public  Const EOF               As Integer = AscW(Char.MinValue) - 1
		Private Const MIN_BUFFER_LENGTH As Integer = 1024                   '  1KB
		Private Const MAX_BUFFER_LENGTH As Integer = MIN_BUFFER_LENGTH * 64 ' 64KB
		Private       buf               As Byte()                           ' input buffer
		Private       bufStart          As Integer                          ' position of first byte in buffer relative to input stream
		Private       bufLen            As Integer                          ' length of buffer
		Private       fileLen           As Integer                          ' length of input stream (may change if the stream is no file)
		Private       bufPos            As Integer                          ' current position in buffer
		Private       stream            As Stream                           ' input stream (seekable)
		Private       isUserStream      As Boolean                          ' was the stream opened by the user?
		Public Sub New(ByVal s As Stream, ByVal isUserStream As Boolean)
			stream = s
			Me.isUserStream = isUserStream
			If stream.CanSeek Then
				fileLen = CInt(stream.Length)
				bufLen = Math.Min(fileLen, MAX_BUFFER_LENGTH)
				bufStart = Int32.MaxValue ' nothing in the buffer so far
			Else
				bufStart = 0
				bufLen   = 0
				fileLen  = 0
			End If
			If bufLen > 0 Then
				buf = New Byte(bufLen - 1) {}
			Else
				buf = New Byte(MIN_BUFFER_LENGTH - 1) {}
			End If
			If fileLen > 0 Then
				Pos = 0    ' setup buffer to position 0 (start)
			Else
				bufPos = 0 ' index 0 is already after the file, thus Pos = 0 is invalid
			End If
			If bufLen = fileLen AndAlso stream.CanSeek Then
				Close()
			End If
		End Sub
		Protected Sub New(ByVal b As Buffer) ' called in UTF8Buffer constructor
			buf = b.buf
			bufStart = b.bufStart
			bufLen = b.bufLen
			fileLen = b.fileLen
			bufPos = b.bufPos
			stream = b.stream
			' keep destructor from closing the stream
			b.stream = Nothing
			isUserStream = b.isUserStream
		End Sub
		Protected Overrides Sub Finalize()
			Try
				Close()
			Finally
				MyBase.Finalize()
			End Try
		End Sub
		Protected Sub Close()
			If Not isUserStream AndAlso stream IsNot Nothing Then
				stream.Close()
				stream = Nothing
			End If
		End Sub
		Public Overridable Function Read() As Integer
			Dim intReturn As Integer
			If bufPos < bufLen Then
				intReturn = buf(bufPos)
				bufPos += 1
			ElseIf Pos < fileLen Then
				Pos = Pos ' shift buffer start to Pos
				intReturn = buf(bufPos)
				bufPos += 1
			ElseIf stream IsNot Nothing AndAlso Not stream.CanSeek AndAlso ReadNextStreamChunk() > 0 Then
				intReturn = buf(bufPos)
				bufPos += 1
			Else
				intReturn = EOF
			End If
			Return intReturn
		End Function
		Public Function Peek() As Integer
			Dim curPos As Integer = Pos
			Dim ch As Integer = Read()
			Pos = curPos
			Return ch
		End Function
		Public Function GetString(ByVal beg As Integer, ByVal [end] As Integer) As String
			Dim len As Integer = 0
			Dim buf As Char() = New Char([end] - beg) {}
			Dim oldPos As Integer = Pos
			Pos = beg
			While Pos < [end]
				Dim ch As Integer = Read()
				buf(len) = ChrW(ch)
				len += 1
			End While
			Pos = oldPos
			Return New String(buf, 0, len)
		End Function
		Public Property Pos() As Integer
			Get
				Return bufPos + bufStart
			End Get
			Set
				If value >= fileLen AndAlso stream IsNot Nothing AndAlso Not stream.CanSeek Then
					' Wanted position is after buffer and the stream
					' is not seek-able e.g. network or console,
					' thus we have to read the stream manually till
					' the wanted position is in sight.
					While value >= fileLen AndAlso ReadNextStreamChunk() > 0
					End While
				End If
				If value < 0 OrElse value > fileLen Then
					Throw New FatalError([String].Format("buffer out of bounds access, position: {0}", value))
				End If
				If value >= bufStart AndAlso value < bufStart + bufLen Then ' already in buffer
					bufPos = value - bufStart
				ElseIf stream IsNot Nothing Then ' must be swapped in
					stream.Seek(value, SeekOrigin.Begin)
					bufLen = stream.Read(buf, 0, buf.Length)
					bufStart = value
					bufPos = 0
				Else
					' set the position to the end of the file, Pos will return fileLen.
					bufPos = fileLen - bufStart
				End If
			End Set
		End Property
		' Read the next chunk of bytes from the stream, increases the buffer
		' if needed and updates the fields fileLen and bufLen.
		' Returns the number of bytes read.
		Private Function ReadNextStreamChunk() As Integer
			Dim free As Integer = buf.Length - bufLen
			If free = 0 Then
				' in the case of a growing input stream
				' we can neither seek in the stream, nor can we
				' foresee the maximum length, thus we must adapt
				' the buffer size on demand.
				Dim newBuf As Byte() = New Byte(bufLen * 2 - 1) {}
				Array.Copy(buf, newBuf, bufLen)
				buf = newBuf
				free = bufLen
			End If
			Dim read As Integer = stream.Read(buf, bufLen, free)
			If read > 0 Then
				bufLen += read
				fileLen = bufLen
				Return read
			End If
			' end of stream reached
			Return 0
		End Function
	End Class

	Public Class UTF8Buffer
		Inherits Buffer
		Public Sub New(ByVal b As Buffer)
			MyBase.New(b)
		End Sub
		Public Overloads Overrides Function Read() As Integer
			Dim ch As Integer
			Do
				' until we find a utf8 start (0xxxxxxx or 11xxxxxx)
				ch = MyBase.Read()
			Loop While (ch >= 128) AndAlso ((ch And 192) <> 192) AndAlso (ch <> EOF)
			If ch < 128 OrElse ch = EOF Then
				' nothing to do, first 127 chars are the same in ascii and utf8
				' 0xxxxxxx or end of file character
			ElseIf (ch And 240) = 240 Then
				' 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx
				Dim c1 As Integer = ch And 7
				ch = MyBase.Read()
				Dim c2 As Integer = ch And 63
				ch = MyBase.Read()
				Dim c3 As Integer = ch And 63
				ch = MyBase.Read()
				Dim c4 As Integer = ch And 63
				ch = (((((c1 << 6) Or c2) << 6) Or c3) << 6) Or c4
			ElseIf (ch And 224) = 224 Then
				' 1110xxxx 10xxxxxx 10xxxxxx
				Dim c1 As Integer = ch And 15
				ch = MyBase.Read()
				Dim c2 As Integer = ch And 63
				ch = MyBase.Read()
				Dim c3 As Integer = ch And 63
				ch = (((c1 << 6) Or c2) << 6) Or c3
			ElseIf (ch And 192) = 192 Then
				' 110xxxxx 10xxxxxx
				Dim c1 As Integer = ch And 31
				ch = MyBase.Read()
				Dim c2 As Integer = ch And 63
				ch = (c1 << 6) Or c2
			End If
			Return ch
		End Function
	End Class

	Public Class Scanner
		Private Const           EOL     As Char      = ChrW(10)
		Private Const           eofSym  As Integer   =  0                  ' pdt
		Private Const           maxT    As Integer   = 28
		Private Const           noSym   As Integer   = 28
		Public                  buffer  As Buffer                          ' scanner buffer
		Private                 t       As Token                           ' current token
		Private                 ch      As Integer                         ' current input character
		Private                 pos     As Integer                         ' byte position of current character
		Private                 col     As Integer                         ' column number of current character
		Private                 line    As Integer                         ' line number of current character
		Private                 oldEols As Integer                         ' EOLs that appeared in a comment
		Private Shared ReadOnly start   As Hashtable                       ' maps first token character to start state
		Private                 tokens  As Token                           ' list of tokens already peeked (first token is a dummy)
		Private                 pt      As Token                           ' current peek token
		Private                 tval()  As Char      = New Char(128) {}    ' text of current token
		Private                 tlen    As Integer                         ' length of current token
		Shared Sub New()
			start = New Hashtable(128)
			For i As Integer =   65 To   90
				start(i) =    1
			Next
			For i As Integer =   97 To  122
				start(i) =    1
			Next
			For i As Integer =   48 To   57
				start(i) =    2
			Next
			start(       123) =    3
			start(       125) =    4
			start(        44) =    5
			start(        59) =    6
			start(        40) =    7
			start(        41) =    8
			start(        61) =   16
			start(        45) =    9
			start(        42) =   10
			start(        47) =   11
			start(        43) =   12
			start(        60) =   14
			start(        62) =   15
			start(Buffer.EOF) =   -1
		End Sub
		Public Sub New(ByVal fileName As String)
			Try
				Dim stream As Stream = New FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read)
				buffer = New Buffer(stream, False)
				Init()
			Catch generatedExceptionName As IOException
				Throw New FatalError("Cannot open file " & fileName)
			End Try
		End Sub
		Public Sub New(ByVal s As Stream)
			buffer = New Buffer(s, True)
			Init()
		End Sub
		Private Sub Init()
			pos = -1
			line = 1
			col = 0
			oldEols = 0
			NextCh()
			If ch = 239 Then
				' check optional byte order mark for UTF-8
				NextCh()
				Dim ch1 As Integer = ch
				NextCh()
				Dim ch2 As Integer = ch
				If ch1 <> 187 OrElse ch2 <> 191 Then
					Throw New FatalError([String].Format("illegal byte order mark: EF {0,2:X} {1,2:X}", ch1, ch2))
				End If
				buffer = New UTF8Buffer(buffer)
				col = 0
				NextCh()
			End If
			tokens = New Token()
			pt = tokens ' first token is a dummy
		End Sub
		Private Sub NextCh()
			If oldEols > 0 Then
				ch = AscW(EOL)
				oldEols -= 1
			Else
				pos = buffer.Pos
				ch = buffer.Read()
				col += 1
				' replace isolated '\r' by '\n' in order to make
				' eol handling uniform across Windows, Unix and Mac
				If ch = 13 AndAlso buffer.Peek() <> 10 Then
					ch = AscW(EOL)
				End If
				If ch = AscW(EOL) Then
					line += 1
					col = 0
				End If
			End If
		End Sub
		Private Sub AddCh()
			If tlen >= tval.Length Then
				Dim newBuf() As Char = New Char(2 * tval.Length) {}
				Array.Copy(tval, 0, newBuf, 0, tval.Length)
				tval = newBuf
			End If
			If ch <> Buffer.EOF Then
				tval(tlen) = ChrW(ch)
				tlen += 1
				NextCh()
			End If
		End Sub
		Private Function Comment0() As Boolean
			Dim level As Integer = 1
			Dim pos0  As Integer = pos
			Dim line0 As Integer = line
			Dim col0  As Integer = col
			NextCh()
			If ch = AscW("/"C) Then
				NextCh()
				While True
					If ch = 10 Then
						level -= 1
						If level = 0 Then
							oldEols = line - line0
							NextCh()
							Return True
						End If
						NextCh()
					ElseIf ch = Buffer.EOF Then
						Return False
					Else
						NextCh()
					End If
				End While
			Else
				buffer.Pos = pos0
				NextCh()
				line = line0
				col = col0
			End If
			Return False
		End Function
		Private Function Comment1() As Boolean
			Dim level As Integer = 1
			Dim pos0  As Integer = pos
			Dim line0 As Integer = line
			Dim col0  As Integer = col
			NextCh()
			If ch = AscW("*"C) Then
				NextCh()
				While True
					If ch = AscW("*"C) Then
						NextCh()
						If ch = AscW("/"C) Then
							level -= 1
							If level = 0 Then
								oldEols = line - line0
								NextCh()
								Return True
							End If
							NextCh()
						End If
					ElseIf ch = AscW("/"C) Then
						NextCh()
						If ch = AscW("*"C) Then
							level += 1
							NextCh()
						End If
					ElseIf ch = Buffer.EOF Then
						Return False
					Else
						NextCh()
					End If
				End While
			Else
				buffer.Pos = pos0
				NextCh()
				line = line0
				col = col0
			End If
			Return False
		End Function
		Private Sub CheckLiteral()
			Select Case t.val
				Case "program"       : t.kind =  3
				Case "int"           : t.kind =  8
				Case "bool"          : t.kind =  9
				Case "void"          : t.kind = 10
				Case "if"            : t.kind = 14
				Case "else"          : t.kind = 15
				Case "while"         : t.kind = 16
				Case "read"          : t.kind = 17
				Case "write"         : t.kind = 18
				Case "true"          : t.kind = 20
				Case "false"         : t.kind = 21
				Case Else
			End Select
		End Sub
		Private Function NextToken() As Token
			While ch = AscW(" "C) OrElse _
				ch >= 9 AndAlso ch <= 10 OrElse ch = 13
				NextCh()
			End While
			If ch = AscW("/"C) AndAlso Comment0() OrElse ch = AscW("/"C) AndAlso Comment1() Then
				Return NextToken()
			End If
			t = New Token()
			t.pos = pos
			t.col = col
			t.line = line
			Dim state As Integer
			If start.ContainsKey(ch) Then
				state = CType(start(ch), Integer)
			Else
				state = 0
			End If
			tlen = 0
			AddCh()
			Select Case state
				Case -1 ' NextCh already done
					t.kind = eofSym
				Case 0  ' NextCh already done
				Case_0:
					t.kind = noSym
				Case 1
				Case_1:
					If ch >= AscW("0"C) AndAlso ch <= AscW("9"C) OrElse ch >= AscW("A"C) AndAlso ch <= AscW("Z"C) OrElse ch >= AscW("a"C) AndAlso ch <= AscW("z"C) Then
						AddCh()
						GoTo Case_1
					Else
						t.kind = 1
						t.val = New String(tval, 0, tlen)
						CheckLiteral()
						Return t
					End If
				Case 2
				Case_2:
					If ch >= AscW("0"C) AndAlso ch <= AscW("9"C) Then
						AddCh()
						GoTo Case_2
					Else
						t.kind = 2
					End If
				Case 3
				Case_3:
					t.kind = 4
				Case 4
				Case_4:
					t.kind = 5
				Case 5
				Case_5:
					t.kind = 6
				Case 6
				Case_6:
					t.kind = 7
				Case 7
				Case_7:
					t.kind = 11
				Case 8
				Case_8:
					t.kind = 12
				Case 9
				Case_9:
					t.kind = 19
				Case 10
				Case_10:
					t.kind = 22
				Case 11
				Case_11:
					t.kind = 23
				Case 12
				Case_12:
					t.kind = 24
				Case 13
				Case_13:
					t.kind = 25
				Case 14
				Case_14:
					t.kind = 26
				Case 15
				Case_15:
					t.kind = 27
				Case 16
				Case_16:
					If ch = AscW("="C) Then
						AddCh()
						GoTo Case_13
					Else
						t.kind = 13
					End If
			End Select
			t.val = New String(tval, 0, tlen)
			Return t
		End Function
		' get the next token (possibly a token already seen during peeking)
		Public Function Scan() As Token
			If tokens.[next] Is Nothing Then
				Return NextToken()
			Else
				tokens = tokens.[next]
				pt = tokens
				Return tokens
			End If
		End Function
		' peek for the next token, ignore pragmas
		Public Function Peek() As Token
			Do
				If pt.[next] Is Nothing Then
					pt.[next] = NextToken()
				End If
				pt = pt.[next]
			Loop While pt.kind > maxT ' skip pragmas
			Return pt
		End Function
		' make sure that peeking starts at the current scan position
		Public Sub ResetPeek()
			pt = tokens
		End Sub
	End Class

End Namespace
