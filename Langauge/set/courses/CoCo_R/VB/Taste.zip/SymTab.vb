Imports System

Namespace Taste

	Public Class Obj            ' object describing a declared name
		Public name    As String  ' name of the object
		Public type    As Integer ' type of the object (undef for proc)
		Public [next]  As Obj     ' to next object in same scope
		Public kind    As Integer ' var, proc, scope
		Public adr     As Integer ' address in memory or start of proc
		Public level   As Integer ' nesting level; 0=global, 1=local
		Public locals  As Obj     ' scopes: to locally declared objects
		Public nextAdr As Integer ' scopes: next free address in this scope
	End Class

	Public Class SymbolTable
		' types
		Const   undef     As Integer = 0
		Const   [Integer] As Integer = 1
		Const   [boolean] As Integer = 2
		' object kinds
		Const   var       As Integer = 0
		Const   proc      As Integer = 1
		Const   scope     As Integer = 2
		Public  curLevel  As Integer     ' nesting level of current scope
		Public  undefObj  As Obj         ' object node for erroneous symbols
		Public  topScope  As Obj         ' topmost procedure scope
		Private parser    As Parser
		Public Sub New(ByVal parser As Parser)
			Me.parser = parser
			topScope = Nothing
			curLevel = -1
			undefObj = New Obj()
			undefObj.name = "undef"
			undefObj.type = undef
			undefObj.kind = var
			undefObj.adr = 0
			undefObj.level = 0
			undefObj.[next] = Nothing
		End Sub
		' open a new scope and make it the current scope (topScope)
		Public Sub OpenScope()
			Dim scop As New Obj()
			scop.name = ""
			scop.kind = scope
			scop.locals = Nothing
			scop.nextAdr = 0
			scop.[next] = topScope
			topScope = scop
			curLevel += 1
		End Sub
		' close the current scope
		Public Sub CloseScope()
			topScope = topScope.[next]
			curLevel -= 1
		End Sub
		' create a new object node in the current scope
		Public Function NewObj(ByVal name As String, ByVal kind As Integer, ByVal type As Integer) As Obj
			Dim p As Obj, last As Obj, obj As New Obj()
			obj.name = name
			obj.kind = kind
			obj.type = type
			obj.level = curLevel
			p = topScope.locals
			last = Nothing
			While p IsNot Nothing
				If p.name = name Then
					parser.SemErr("name declared twice")
				End If
				last = p
				p = p.[next]
			End While
			If last Is Nothing Then
				topScope.locals = obj
			Else
				last.[next] = obj
			End If
			If kind = var Then
				obj.adr = topScope.nextAdr : topScope.nextAdr += 1
			End If
			Return obj
		End Function
		' search the name in all open scopes and return its object node
		Public Function Find(ByVal name As String) As Obj
			Dim obj As Obj, scope As Obj
			scope = topScope
			While scope IsNot Nothing
				' for all open scopes
				obj = scope.locals
				While obj IsNot Nothing
					' for all objects in this scope
					If obj.name = name Then
						Return obj
					End If
					obj = obj.[next]
				End While
				scope = scope.[next]
			End While
			parser.SemErr(name + " is undeclared")
			Return undefObj
		End Function
	End Class

End Namespace
