Imports System

Namespace Taste

	Class Taste
		Public Shared Sub Main(ByVal arg() As String)
			If arg.Length > 0 Then
				Dim scanner As New Scanner(arg(0))
				Dim parser As New Parser(scanner)
				parser.tab = New SymbolTable(parser)
				parser.gen = New CodeGenerator()
				parser.Parse()
				If parser.errors.count = 0 Then
					parser.gen.Decode()
					parser.gen.Interpret("Taste.IN")
				End If
			Else
				Console.WriteLine("-- No source file specified")
			End If
		End Sub
	End Class

End Namespace
