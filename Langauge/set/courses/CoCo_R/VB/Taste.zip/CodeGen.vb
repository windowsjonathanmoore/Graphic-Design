Imports System
Imports System.IO

Namespace Taste

	Public Enum Op
		' opcodes
		ADD
		[SUB]
		MUL
		DIV
		EQU
		LSS
		GTR
		NEG
		LOAD
		LOADG
		STO
		STOG
		[CONST]
		[CALL]
		RET
		ENTER
		LEAVE
		JMP
		FJMP
		READ
		WRITE
	End Enum

	Public Class CodeGenerator
		Private opcode() As String = { _
			"ADD  ", _
			"SUB  ", _
			"MUL  ", _
			"DIV  ", _
			"EQU  ", _
			"LSS  ", _
			"GTR  ", _
			"NEG  ", _
			"LOAD ", _
			"LOADG", _
			"STO  ", _
			"STOG ", _
			"CONST", _
			"CALL ", _
			"RET  ", _
			"ENTER", _
			"LEAVE", _
			"JMP  ", _
			"FJMP ", _
			"READ ", _
			"WRITE" _
		}
		Public progStart As Integer ' address of first instruction of main program
		Public pc As Integer ' program counter
		Private code() As Byte = New Byte(3000) {} ' data for Interpret
		Private globals() As Integer = New Integer(100) {}
		Private stack() As Integer = New Integer(100) {}
		Private top As Integer ' top of stack
		Private bp As Integer ' base pointer
		Public Sub New()
			pc = 1
			progStart = -1
		End Sub
		'----- code generation methods -----
		Public Sub Put(ByVal x As Integer)
			code(pc) = CByte(x)
			pc += 1
		End Sub
		Public Sub Emit(ByVal op As Op)
			Put(op)
		End Sub
		Public Sub Emit(ByVal op As Op, ByVal val As Integer)
			Emit(op)
			Put(val >> 8)
			Put(val)
		End Sub
		Public Sub Patch(ByVal adr As Integer, ByVal val As Integer)
			code(adr) = CByte(val >> 8)
			code(adr + 1) = CByte(val)
		End Sub
		Public Sub Decode()
			Dim maxPc As Integer = pc
			pc = 1
			While pc < maxPc
				Dim code As Op = [Next]()
				Console.Write("{0,3}: {1} ", pc - 1, opcode(code))
				Select Case code
					Case Op.LOAD, Op.LOADG, Op.[CONST], Op.STO, Op.STOG, Op.[CALL], Op.ENTER, Op.JMP, Op.FJMP
						Console.WriteLine(Next2())
					Case Op.ADD, Op.[SUB], Op.MUL, Op.DIV, Op.NEG, Op.EQU, Op.LSS, Op.GTR, Op.RET, Op.LEAVE, Op.READ, Op.WRITE
						Console.WriteLine()
				End Select
			End While
		End Sub
		'----- interpreter methods -----
		Private Function [Next]() As Integer
			Dim bytReturn As Byte = code(pc)
			pc += 1
			Return bytReturn
		End Function
		Private Function Next2() As Integer
			Dim x As Integer, y As Integer
			x = code(pc) : pc += 1
			y = code(pc) : pc += 1
			Return (x << 8) + y
		End Function
		Private Function Int(ByVal b As Boolean) As Integer
			If b Then
				Return 1
			Else
				Return 0
			End If
		End Function
		Private Sub Push(ByVal val As Integer)
			stack(top) = val : top += 1
		End Sub
		Private Function Pop() As Integer
			top -= 1
			Return stack(top)
		End Function
		Private Function ReadInt(ByVal s As FileStream) As Integer
			Dim ch As Integer, sign As Integer
			Do
				ch = s.ReadByte()
			Loop While Not (ch >= AscW("0"C) AndAlso ch <= AscW("9"C) OrElse ch = AscW("-"C))
			If ch = AscW("-"C) Then
				sign = -1
				ch = s.ReadByte()
			Else
				sign = 1
			End If
			Dim n As Integer = 0
			While ch >= AscW("0"C) AndAlso ch <= AscW("9"C)
				n = 10 * n + (ch - AscW("0"C))
				ch = s.ReadByte()
			End While
			Return n * sign
		End Function
		Public Sub Interpret(ByVal data As String)
			Dim val As Integer
			Try
				Dim s As New FileStream(data, FileMode.Open, FileAccess.Read)
				Console.WriteLine()
				pc = progStart
				stack(0) = 0
				top = 1
				bp = 0
				While True
					Select Case [Next]()
						Case Op.[CONST] : Push(Next2())
						Case Op.LOAD    : Push(stack(bp + Next2()))
						Case Op.LOADG   : Push(globals(Next2()))
						Case Op.STO     : stack(bp + Next2()) = Pop()
						Case Op.STOG    : globals(Next2()) = Pop()
						Case Op.ADD     : Push(Pop() + Pop())
						Case Op.[SUB]   : Push(-Pop() + Pop())
						Case Op.DIV     : val = Pop()
						                  Push(Pop() / val)
						Case Op.MUL     : Push(Pop() * Pop())
						Case Op.NEG     : Push(-Pop())
						Case Op.EQU     : Push(Int(Pop() = Pop()))
						Case Op.LSS     : Push(Int(Pop() > Pop()))
						Case Op.GTR     : Push(Int(Pop() < Pop()))
						Case Op.JMP     : pc = Next2()
						Case Op.FJMP    : val = Next2()
						                  If Pop() = 0 Then pc = val
						Case Op.READ    : val = ReadInt(s)
						                  Push(val)
						Case Op.WRITE   : Console.WriteLine(Pop())
						Case Op.[CALL]  : Push(pc + 2)
						                  pc = Next2()
						Case Op.RET     : pc = Pop()
						                  If pc = 0 Then Return
						Case Op.ENTER   : Push(bp)
						                  bp = top
						                  top += Next2()
						Case Op.LEAVE   : top = bp
						                  bp = Pop()
						Case Else       : Throw New Exception("illegal opcode")
					End Select
				End While
			Catch generatedExceptionName As IOException
				Console.WriteLine("--- Error accessing file {0}", data)
				Environment.[Exit](0)
			End Try
		End Sub
	End Class

End Namespace
