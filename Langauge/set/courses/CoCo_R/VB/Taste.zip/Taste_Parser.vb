Option Compare Binary
Option Explicit On
Option Strict On

Imports System
Imports System.IO

Namespace Taste

	Public Class Parser
		Public  Const   _EOF        As Integer =  0
		Public  Const   _ident      As Integer =  1
		Public  Const   _number     As Integer =  2
		Public  Const   maxT        As Integer = 28
		Private Const   blnT        As Boolean = True
		Private Const   blnX        As Boolean = False
		Private Const   minErrDist  As Integer =  2
		Public          scanner     As Scanner
		Public          errors      As Errors
		Public          t           As Token                ' last recognized token
		Public          la          As Token                ' lookahead token
		Private         errDist     As Integer = minErrDist
		' types
		Private Const   undef       As Integer = 0
		Private Const   [integer]   As Integer = 1
		Private Const   [boolean]   As Integer = 2
		' object kinds
		Private Const   var         As Integer = 0
		Private Const   proc        As Integer = 1
		Public          tab         As SymbolTable
		Public          gen         As CodeGenerator
		Public Sub New(ByVal scanner As Scanner)
			Me.scanner = scanner
			errors = New Errors()
		End Sub
		Private Sub SynErr(ByVal n As Integer)
			If errDist >= minErrDist Then
				errors.SynErr(la.line, la.col, n)
			End If
			errDist = 0
		End Sub
		Public Sub SemErr(ByVal msg As String)
			If errDist >= minErrDist Then
				errors.SemErr(t.line, t.col, msg)
			End If
			errDist = 0
		End Sub
		Private Sub [Get]()
			While True
				t = la
				la = scanner.Scan()
				If la.kind <= maxT Then
					errDist += 1
					Exit While
				End If
				la = t
			End While
		End Sub
		Private Sub Expect(ByVal n As Integer)
			If la.kind = n Then
				[Get]()
			Else
				SynErr(n)
			End If
		End Sub
		Private Function StartOf(ByVal s As Integer) As Boolean
			Return blnSet(s, la.kind)
		End Function
		Private Sub ExpectWeak(ByVal n As Integer, ByVal follow As Integer)
			If la.kind = n Then
				[Get]()
			Else
				SynErr(n)
				While Not StartOf(follow)
					[Get]()
				End While
			End If
		End Sub
		Private Function WeakSeparator(ByVal n As Integer, ByVal syFol As Integer, ByVal repFol As Integer) As Boolean
			Dim kind As Integer = la.kind
			If kind = n Then
				[Get]()
				Return True
			ElseIf StartOf(repFol) Then
				Return False
			Else
				SynErr(n)
				While Not (blnSet(syFol, kind) OrElse blnSet(repFol, kind) OrElse blnSet(0, kind))
					[Get]()
					kind = la.kind
				End While
				Return StartOf(syFol)
			End If
		End Function
		Private Sub Taste()
			Dim name As String = Nothing
			Expect(3)
			Ident(name)
			tab.OpenScope()
			Expect(4)
			While la.kind = 8 OrElse la.kind = 9 OrElse la.kind = 10
				If la.kind = 8 OrElse la.kind = 9 Then
					VarDecl()
				Else
					ProcDecl()
				End If
			End While
			Expect(5)
			tab.CloseScope()
			If gen.progStart = -1 Then
				SemErr("main function never defined")
			End If
		End Sub
		Private Sub Ident(ByRef name As String)
			Expect(1)
			name = t.val
		End Sub
		Private Sub VarDecl()
			Dim name As String = Nothing
			Dim _type As Integer
			Type(_type)
			Ident(name)
			tab.NewObj(name, var, _type)
			While la.kind = 6
				[Get]()
				Ident(name)
				tab.NewObj(name, var, _type)
			End While
			Expect(7)
		End Sub
		Private Sub ProcDecl()
			Dim name As String = Nothing
			Dim obj As Obj
			Dim adr As Integer
			Expect(10)
			Ident(name)
			obj = tab.NewObj(name, proc, undef)
			obj.adr = gen.pc
			If name = "Main" Then
				gen.progStart = gen.pc
			End If
			tab.OpenScope()
			Expect(11)
			Expect(12)
			Expect(4)
			gen.Emit(Op.ENTER, 0)
			adr = gen.pc - 2
			While StartOf(1)
				If la.kind = 8 OrElse la.kind = 9 Then
					VarDecl()
				Else
					Stat()
				End If
			End While
			Expect(5)
			gen.Emit(Op.LEAVE)
			gen.Emit(Op.RET)
			gen.Patch(adr, tab.topScope.nextAdr)
			tab.CloseScope()
		End Sub
		Private Sub Type(ByRef _type As Integer)
			_type = undef
			If la.kind = 8 Then
				[Get]()
				_type = [integer]
			ElseIf la.kind = 9 Then
				[Get]()
				_type = [boolean]
			Else
				SynErr(29)
			End If
		End Sub
		Private Sub Stat()
			Dim type As Integer
			Dim name As String = Nothing
			Dim obj As Obj
			Dim adr As Integer, adr2 As Integer, loopstart As Integer
			Select Case la.kind
				Case 1
					Ident(name)
					obj = tab.Find(name)
					If la.kind = 13 Then
						[Get]()
						If obj.kind <> var Then
							SemErr("cannot assign to procedure")
						End If
						Expr(type)
						Expect(7)
						If type <> obj.type Then
							SemErr("incompatible types")
						End If
						If obj.level = 0 Then
							gen.Emit(Op.STOG, obj.adr)
						Else
							gen.Emit(Op.STO, obj.adr)
						End If
					ElseIf la.kind = 11 Then
						[Get]()
						Expect(12)
						Expect(7)
						If obj.kind <> proc Then
							SemErr("object is not a procedure")
						End If
						gen.Emit(Op.[CALL], obj.adr)
					Else
						SynErr(30)
					End If
				Case 14
					[Get]()
					Expect(11)
					Expr(type)
					Expect(12)
					If type <> [boolean] Then
						SemErr("boolean type expected")
					End If
					gen.Emit(Op.FJMP, 0)
					adr = gen.pc - 2
					Stat()
					If la.kind = 15 Then
						[Get]()
						gen.Emit(Op.JMP, 0)
						adr2 = gen.pc - 2
						gen.Patch(adr, gen.pc)
						adr = adr2
						Stat()
					End If
					gen.Patch(adr, gen.pc)
				Case 16
					[Get]()
					loopstart = gen.pc
					Expect(11)
					Expr(type)
					Expect(12)
					If type <> [boolean] Then
						SemErr("boolean type expected")
					End If
					gen.Emit(Op.FJMP, 0)
					adr = gen.pc - 2
					Stat()
					gen.Emit(Op.JMP, loopstart)
					gen.Patch(adr, gen.pc)
				Case 17
					[Get]()
					Ident(name)
					Expect(7)
					obj = tab.Find(name)
					If obj.type <> [integer] Then
						SemErr("integer type expected")
					End If
					gen.Emit(Op.READ)
					If obj.level = 0 Then
						gen.Emit(Op.STOG, obj.adr)
					Else
						gen.Emit(Op.STO, obj.adr)
					End If
				Case 18
					[Get]()
					Expr(type)
					Expect(7)
					If type <> [integer] Then
						SemErr("integer type expected")
					End If
					gen.Emit(Op.WRITE)
				Case 4
					[Get]()
					While StartOf(1)
						If StartOf(2) Then
							Stat()
						Else
							VarDecl()
						End If
					End While
					Expect(5)
				Case Else
					SynErr(31)
			End Select
		End Sub
		Private Sub Expr(ByRef type As Integer)
			Dim type1 As Integer
			Dim op As Op
			SimExpr(type)
			If la.kind = 25 OrElse la.kind = 26 OrElse la.kind = 27 Then
				RelOp(op)
				SimExpr(type1)
				If type <> type1 Then
					SemErr("incompatible types")
				End If
				gen.Emit(op)
				type = [boolean]
			End If
		End Sub
		Private Sub SimExpr(ByRef type As Integer)
			Dim type1 As Integer
			Dim op As Op
			Term(type)
			While la.kind = 19 OrElse la.kind = 24
				AddOp(op)
				Term(type1)
				If type <> [integer] OrElse type1 <> [integer] Then
					SemErr("integer type expected")
				End If
				gen.Emit(op)
			End While
		End Sub
		Private Sub RelOp(ByRef op As Op)
			op = Op.EQU
			If la.kind = 25 Then
				[Get]()
			ElseIf la.kind = 26 Then
				[Get]()
				op = Op.LSS
			ElseIf la.kind = 27 Then
				[Get]()
				op = Op.GTR
			Else
				SynErr(32)
			End If
		End Sub
		Private Sub Term(ByRef type As Integer)
			Dim type1 As Integer
			Dim op As Op
			Factor(type)
			While la.kind = 22 OrElse la.kind = 23
				MulOp(op)
				Factor(type1)
				If type <> [integer] OrElse type1 <> [integer] Then
					SemErr("integer type expected")
				End If
				gen.Emit(op)
			End While
		End Sub
		Private Sub AddOp(ByRef op As Op)
			op = Op.ADD
			If la.kind = 24 Then
				[Get]()
			ElseIf la.kind = 19 Then
				[Get]()
				op = Op.[SUB]
			Else
				SynErr(33)
			End If
		End Sub
		Private Sub Factor(ByRef type As Integer)
			Dim n As Integer
			Dim obj As Obj
			Dim name As String = Nothing
			type = undef
			If la.kind = 1 Then
				Ident(name)
				obj = tab.Find(name)
				type = obj.type
				If obj.kind = var Then
					If obj.level = 0 Then
						gen.Emit(Op.LOADG, obj.adr)
					Else
						gen.Emit(Op.LOAD, obj.adr)
					End If
				Else
					SemErr("variable expected")
				End If
			ElseIf la.kind = 2 Then
				[Get]()
				n = Convert.ToInt32(t.val)
				gen.Emit(Op.[CONST], n)
				type = [integer]
			ElseIf la.kind = 19 Then
				[Get]()
				Factor(type)
				If type <> [integer] Then
					SemErr("integer type expected")
					type = [integer]
				End If
				gen.Emit(Op.NEG)
			ElseIf la.kind = 20 Then
				[Get]()
				gen.Emit(Op.[CONST], 1)
				type = [boolean]
			ElseIf la.kind = 21 Then
				[Get]()
				gen.Emit(Op.[CONST], 0)
				type = [boolean]
			Else
				SynErr(34)
			End If
		End Sub
		Private Sub MulOp(ByRef op As Op)
			op = Op.MUL
			If la.kind = 22 Then
				[Get]()
			ElseIf la.kind = 23 Then
				[Get]()
				op = Op.DIV
			Else
				SynErr(35)
			End If
		End Sub
		Public Sub Parse()
			la = New Token()
			la.val = ""
			[Get]()
			Taste()
			Expect(0)
		End Sub
		Private Shared ReadOnly blnSet(,) As Boolean = { _
			{blnT,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX}, _
			{blnX,blnT,blnX,blnX, blnT,blnX,blnX,blnX, blnT,blnT,blnX,blnX, blnX,blnX,blnT,blnX, blnT,blnT,blnT,blnX, blnX,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX}, _
			{blnX,blnT,blnX,blnX, blnT,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX,blnT,blnX, blnT,blnT,blnT,blnX, blnX,blnX,blnX,blnX, blnX,blnX,blnX,blnX, blnX,blnX} _
		}
	End Class

	Public Class Errors
		Public count        As Integer                                 ' number of errors detected
		Public errorStream  As TextWriter = Console.Out                ' error messages go to this stream
		Public errMsgFormat As String     = "-- line {0} col {1}: {2}" ' 0=line, 1=column, 2=text
		Public Sub SynErr(ByVal line As Integer, ByVal col As Integer, ByVal n As Integer)
			Dim s As String
			Select Case n
				Case    0 : s = "EOF expected"
				Case    1 : s = "ident expected"
				Case    2 : s = "number expected"
				Case    3 : s = """program"" expected"
				Case    4 : s = """{"" expected"
				Case    5 : s = """}"" expected"
				Case    6 : s = ""","" expected"
				Case    7 : s = """;"" expected"
				Case    8 : s = """int"" expected"
				Case    9 : s = """bool"" expected"
				Case   10 : s = """void"" expected"
				Case   11 : s = """("" expected"
				Case   12 : s = """)"" expected"
				Case   13 : s = """="" expected"
				Case   14 : s = """if"" expected"
				Case   15 : s = """else"" expected"
				Case   16 : s = """while"" expected"
				Case   17 : s = """read"" expected"
				Case   18 : s = """write"" expected"
				Case   19 : s = """-"" expected"
				Case   20 : s = """true"" expected"
				Case   21 : s = """false"" expected"
				Case   22 : s = """*"" expected"
				Case   23 : s = """/"" expected"
				Case   24 : s = """+"" expected"
				Case   25 : s = """=="" expected"
				Case   26 : s = """<"" expected"
				Case   27 : s = """>"" expected"
				Case   28 : s = "??? expected"
				Case   29 : s = "invalid Type"
				Case   30 : s = "invalid Stat"
				Case   31 : s = "invalid Stat"
				Case   32 : s = "invalid RelOp"
				Case   33 : s = "invalid AddOp"
				Case   34 : s = "invalid Factor"
				Case   35 : s = "invalid MulOp"
				Case Else : s = "error " & n
			End Select
			errorStream.WriteLine(errMsgFormat, line, col, s)
			count += 1
		End Sub
		Public Sub SemErr(ByVal line As Integer, ByVal col As Integer, ByVal s As String)
			errorStream.WriteLine(errMsgFormat, line, col, s)
			count += 1
		End Sub
		Public Sub SemErr(ByVal s As String)
			errorStream.WriteLine(s)
			count += 1
		End Sub
		Public Sub Warning(ByVal line As Integer, ByVal col As Integer, ByVal s As String)
			errorStream.WriteLine(errMsgFormat, line, col, s)
		End Sub
		Public Sub Warning(ByVal s As String)
			errorStream.WriteLine(s)
		End Sub
	End Class

	Public Class FatalError
		Inherits Exception
		Public Sub New(ByVal m As String)
			MyBase.New(m)
		End Sub
	End Class

End Namespace
