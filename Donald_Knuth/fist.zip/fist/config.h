/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H

/* Define if you have the <strings.h> header file.  */
#undef HAVE_STRINGS_H

/* Define if you have the <unistd.h> header file.  */
#undef HAVE_UNISTD_H

/* The following definitions indicate which utilities are available
   for expanding compressed archive files. */
#undef HAVE_GUNZIP
#undef HAVE_GZCAT
#undef HAVE_GZIP
#undef HAVE_ZCAT
#undef HAVE_UNCOMPRESS
#undef HAVE_COMPRESS

/* Define to the name of the distribution.  */
#undef PRODUCT

/* Define to the version of the distribution.  */
/* #undef VERSION */
