#include <iostream.h>
#include <math/cholesky.h>
#include <math/symmetric.h>
#include <math/fstream.h>
#include <stdlib.h>

#include "print.h"

int main()
{
    try
    {
        math::matrix<double,math::symmetric> A;
        math::matrix<double,math::unstructured> Afull;
        math::matrix<double> b;
        math::ifstream file("matrices.mat");
        
        file.skipto("A3");
        file >> A;
        Afull=A;
        print(A);
        cout << endl << "Cholesky decomposition - symmetric" << endl << endl;
        math::cholesky::decompose(A);
        print(A);
        cout << endl << "Cholesky decomposition - full" << endl << endl;
        math::cholesky::decompose(Afull);
        print(Afull);

        file.skipto("A3");
        file >> A >> b;
        cout << endl << endl << "Ax=b - symmetric" << endl << endl;
        math::cholesky::solve(A,b);
        print(b);        

        file.skipto("A3");
        file >> Afull >> b;
        cout << endl << endl << "Ax=b - full" << endl << endl;
        math::cholesky::solve(Afull,b);
        print(b);        
    }
    catch(math::error::generic e)
    {
        cout << e.message() << endl;
    }
    return 0;
}
