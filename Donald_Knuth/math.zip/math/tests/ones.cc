#include <iostream.h>
#include <math/ones.h>

void print(const math::matrix<double>& A)
{
    cout << "Matrix (" << A.rows() << ',' << A.cols() << ") =\n";
    for(math::index i=1;i<=A.rows();i++)
    {
        for(math::index j=1;j<=A.cols();j++)
            cout << A(i,j) << '\t';
        cout << endl;
    }
    cout << endl;
}


main()
{
    math::matrix<double> I = math::ones<double>(4,3);
    print(I);

    // The next line is generating an internal compiler error.
    // I=math::ones<double>(I);
}
