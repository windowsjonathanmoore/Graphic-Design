#include <iostream>
#include <math/functional/gaxpy.h>
#include <math/linesearch/bisection.h>
#include <math/linesearch/backtracking.h>
#include <math/searchdir/gradient.h>
#include <math/searchdir/newton.h>
#include <math/barrier/log.h>
#include <math/fmin.h>
#include <math/cholesky.h>
#include <math/sumt.h>

#include "print.h"


int main(void)
{
   try
     {
	typedef vector<math::barrier::base<double>*> sumt_list;

        // minimize cx subject to x>1 ( or 1-x<0 )
	//                        x<4 ( or x-4<0 )
	math::matrix<double> c(1,1,1);
	math::matrix<double> a(1,1,-1);
	math::matrix<double> b(1,1,1);
	
	math::functional::gaxpy<double,math::unstructured,math::dense> cost(c,0.0);
	math::functional::gaxpy<double,math::unstructured,math::dense> constraint1(a,1);
	math::functional::gaxpy<double,math::unstructured,math::dense> constraint2(b,-4);
	math::barrier::log<double> barrier1(&constraint1);
	math::barrier::log<double> barrier2(&constraint2);

	sumt_list constraints_list;
	constraints_list.push_back(&barrier1);
	constraints_list.push_back(&barrier2);
	
	math::matrix<double> x(1,1,-5);
	math::linesearch::bisection<double> line1(1e-7);
	math::linesearch::backtracking<double> line2;
	math::searchdir::gradient<double> graddir;
	math::searchdir::newton<double,math::dense> newtdir;

 	math::sumt(&cost,constraints_list,x,&line1,&newtdir,1e-4,1e-2);
	cout << "Minimization with bisection gives ";
	print(x);

	x.entry(1,1)=-5;
	math::sumt(&cost,constraints_list,x,&line2,&newtdir,1e-4,1e-2);
	cout << "Minimization with backtracking gives ";
	print(x);
    }
    catch(math::error::generic e)
    {
       cout << "Error: " << e.message() << endl;
    }
}
