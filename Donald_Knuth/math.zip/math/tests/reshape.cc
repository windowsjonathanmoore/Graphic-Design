#include <fstream>
#include <iostream>
#include <math/fstream.h>

#include "print.h"

main()
{
    math::ifstream file("AB.mat");
    math::matrix<double> A;

    file >> A;
    print(A);

    cout << "Reshaping to (3,2)" << endl;
    print(reshape(&A,3,2));
    
    cout << "Reshaping to (6,1)" << endl;
    print(reshape(&A,6,1));

    cout << "Reshaping to (1,6)" << endl;
    print(reshape(&A,1,6));

    cout << "Reshaping to (2,3)" << endl;
    print(reshape(&A,2,3));
}
