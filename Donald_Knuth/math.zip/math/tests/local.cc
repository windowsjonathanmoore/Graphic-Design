#include <iostream>
#include <math/functional/quadratic.h>
#include <math/linesearch/bisection.h>
#include <math/searchdir/gradient.h>
#include <math/searchdir/newton.h>
#include <math/fmin.h>
#include <math/cholesky.h>

#include "print.h"

int main(void)
{
    try
    {
	math::matrix<double,math::symmetric> P(2,2);
	math::matrix<double> p(2,1),d;
	
	P.entry(1,1)=2;	P.entry(1,2)=3;	P.entry(2,2)=7;
	p.entry(1)=-2; p.entry(2)=-8;

	cout << "P="; print(P);
	cout << "p="; print(p);
	cout << "pi=10" << endl << endl;
	
	math::functional::quadratic<double,math::dense> f(P,p,10);

	math::matrix<double> x(2,1);
	math::matrix<double> grad(2,1);
	x.entry(1)=-1;
	x.entry(2)=5;


	math::linesearch::bisection<double> line(1e-7);
	math::searchdir::gradient<double> graddir;
	math::searchdir::newton<double,math::dense> newtdir;

	cout << "Minimization at [ -1 5 ] gives ";
	print(x=line.minimize(&f,x,graddir.dir(&f,x,&d)));
	print(x=line.minimize(&f,x,graddir.dir(&f,x,&d)));
	print(x=line.minimize(&f,x,graddir.dir(&f,x,&d)));
	print(x=line.minimize(&f,x,graddir.dir(&f,x,&d)));
	print(x=line.minimize(&f,x,graddir.dir(&f,x,&d)));
	print(x=line.minimize(&f,x,graddir.dir(&f,x,&d)));
	print(x=line.minimize(&f,x,graddir.dir(&f,x,&d)));

	cout << "With fmin, ";
	x.entry(1)=-1; x.entry(2)=5;
	print(math::fmin(&f,x,&line,&graddir));

	cout << "Now with the hessian: ";
	x.entry(1)=-1; x.entry(2)=5;
	print(math::fmin(&f,x,&line,&newtdir));
    }
    catch(math::error::generic e)
    {
    }
}
