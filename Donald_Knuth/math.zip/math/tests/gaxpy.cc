#include <iostream.h>
#include <math/math.h>
#include <math/fstream.h>
#include <math/functional/gaxpy.h>
#include <stdlib.h>

#include "print.h"

main()
{
    try
    {
        math::matrix<double> A,b1,b2,result;
        math::ifstream file("matrices.mat");
        
        file >> A;
        file >> A >> b1 >> A >> b2;

        print(b1); print(b2);
        
        math::functional::gaxpy<double> f(b1,2.0);

        cout << "b1^T*b2+2 = " << f(b2) << endl;
    }
    catch(math::error::generic e)
    {
        cout << e.message() << endl;
    }
}
