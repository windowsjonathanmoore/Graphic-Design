#include <fstream>
#include <iostream>
#include <math/fstream.h>
#include <math/sparse.h>

#include "print.h"

main()
{
    math::ifstream file("AB.mat");
    math::matrix<double,math::unstructured,math::sparse> A;
    math::matrix<complex<double>,math::unstructured,math::sparse> B(3,3);
    math::matrix<double,math::unstructured,math::sparse> huge(100000,100000);

    cout << "Simple input." << endl;
    file >> A >> B;
    print(A); print(B);

    cout << endl << "Jump to second matrix and read it." << endl;
    file.skipto(2);
    file >> B;
    print(B);

    cout << endl << "Jump to matrix B and read it." << endl;
    file.skipto("B");
    file >> B;
    print(B);

    cout << endl << "Should issue an error." << endl;
    try
    {
        file.skipto("oonga!");
    }
    catch(math::error::generic e)
    {
        cout << e.message() << endl;
    }

    math::ofstream out("vomit.mat");
    
    out << "a" << A << "b" << B;

    cout << endl << "Wrote vomit.mat." << endl;
}
