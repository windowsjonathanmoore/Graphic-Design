#include <iostream.h>
#include <math/qr.h>
#include <math/fstream.h>
#include <stdlib.h>

#include "print.h"

main()
{
   try 
     {
	math::matrix<double> A,b;
	math::ifstream file("matrices.mat");
        
	file >> A;
	print(A);
	cout << endl << "QR decomposition" << endl << endl;
	math::qr::decompose(A);
	print(A);
	
	file >> A >> b;
	file.skipto("A5");
	file >> A;
	math::matrix<double> At=math::transpose(A);
	cout << endl << "Ax=b" << endl;
	print(A);
	print(b);
	math::qr::solve(A,b);
	cout << "Least squares solution: ";
	print(b);
	cout << "Minimum norm solution: ";
	math::qr::solve(At,b);
	print(b);
     }
   catch(math::error::generic e)
     {
        cout << e.message() << endl;
     }
}
