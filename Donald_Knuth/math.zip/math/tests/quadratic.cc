#include <iostream>
#include <math/functional/quadratic.h>

#include "print.h"

int main(void)
{
    try
    {
	math::matrix<double,math::symmetric> P(2,2);
	math::matrix<double> p(2,1);
	
	P.entry(1,1)=1;	P.entry(1,2)=3;	P.entry(2,2)=7;
	p.entry(1)=-2; p.entry(2)=-8;

	cout << "P="; print(P);
	cout << "p="; print(p);
	cout << "pi=10" << endl << endl;
	
	math::functional::quadratic<double,math::dense> f(P,p,10);

	math::matrix<double> x(2,1);
	x.entry(1)=-1;
	x.entry(2)=5;

	math::matrix<double> grad(2,1);
	math::matrix<double,math::symmetric> hess(2,2);

	cout << "Value at [ -1 5 ] is " << f(x) << endl << endl;
	cout << "Gradient is "; print(f.grad(x,grad));
	cout << "Hessian is "; print(f.hess(x,hess));
    }
    catch(math::error::generic e)
    {
    }
}
