#include<iostream>

template<class type>
class dense
{
    type value;
public:
    dense(void) { cout << "I'm dense...\n"; }
    ~dense(void) { cout << "I'm dense no more...\n"; }
};

template<class type, template <class T> class structure = dense >
class matrix
{
    structure<type> data;
public:
    matrix(void) { cout << "I'm a matrix...\n"; }
    ~matrix(void) { cout << "I'm a matrix no more...\n"; }
};

main(void)
{
    dense<int> data;
    matrix< int, dense > mat;
    return 0;
}
