#include <iostream.h>

// This is a test for a special template construction that is valid but not accepted
// by g++ 2.8.1. This file serves as a test for which compilers will compile this thing.

template < class type , template < class K > class structure >
class matrix
{
    structure<type> theData;
public:
    matrix(void){cout<<"Compiled! Worked! Yeah!"<<endl;
    }
};

int main(void)
{
    matrix<double,complex> A;
    
    return 1;
}
