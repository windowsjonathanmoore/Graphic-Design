#include<iostream.h>

template<class T>
class templatest
{
    T thing;
public:
    templatest(void) { thing=1; }
    void rows(void) const { cout << "Rows!\n"; }
    void cols(void) const { cout << "Cols!\n"; }
};

template<class T>
void function(const T& thing)
{
    thing.rows();
    thing.cols();
}

main(void)
{
    templatest<int> INT;
    templatest<char> CHAR;
    
    function(INT);
    function(CHAR);
    
    return 0;
}
