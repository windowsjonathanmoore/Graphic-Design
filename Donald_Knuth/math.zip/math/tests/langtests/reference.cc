#include <iostream.h>

// Do we need or not to return a reference for a structure in
// constructions like A(i,j) = 2 ? No we don't and that's good.

// From the output:
//--------------------------------------
// Matrix constructor.
// Entry constructor.
// Matrix()
// Entry destructor.
// Entry assignment method!
// Entry destructor.
// Matrix destructor.

class entry
{
public:
    entry(void) { cout << "Entry constructor.\n"; }
    ~entry(void) { cout << "Entry destructor.\n"; }

    void operator=(int value) { cout << "Entry assignment method!\n"; }
};

class matrix
{
public:
    matrix(void) { cout << "Matrix constructor.\n"; }
    ~matrix(void) { cout << "Matrix destructor.\n"; }

    entry operator()(int value)
    {
        entry _someentry;
        cout << "Matrix ()\n";
        return _someentry;
    }
};

void main(void)
{
    matrix A;

    A(1)=2;
}
