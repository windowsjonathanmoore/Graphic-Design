// This program demonstrates that even if a const method is available the
// compiler will not chose it automatically even when it is possible. Huge
// implications for matrix classes (sparse matrices for example).
#include<iostream.h>

int zero = 0;

template<class T> class matrix;

template<class T>
class entry
{
    matrix<T>* theMatrix;
public:
    entry(matrix<T>* _matrix) : theMatrix(_matrix) { }

    inline operator=(const int& _value) { theMatrix->modify(_value); }
};

template<class T>
class matrix
{
    int value;

public:
    matrix(void) { value = 1; }

    inline const int& operator[](const int) const 
	{ 
            cout << "Const method!\n";
            return value;
        }

    inline entry<T> operator[](const int)
        { 
            cout << "Var method!\n";
            entry<T> _ret(this);
            return _ret;
        }
    
    inline void modify(const int x)
	{
	    value=x;
	}
};

main(void)
{
    matrix<int> instance;
    
    instance[1] = 
        instance[0]*instance[1];

    int value =
        instance[0];

    cout << "\nValue returned: " << instance[1] << endl;

    return 0;
}

