#include <vector>

template<class M>
void print(const M& A)
{
    cout << "Matrix (" << A.rows() << ',' << A.cols() << ") =\n";
    for(math::index i=1;i<=A.rows();i++)
    {
        for(math::index j=1;j<=A.cols();j++)
            cout << A(i,j) << '\t';
        cout << endl;
    }
    cout << endl;
}

void print(vector<math::index>& A)
{
    cout << "Vector (" << A.size() << ") = ";
    for(unsigned int i=0;i<A.size();i++)
        cout << A[i] << ' ';
    cout << endl;
}

extern "C" int MAIN__();
int MAIN__() { return 0; }
//extern "C" int etime_();
//int etime_() { return 0; }

