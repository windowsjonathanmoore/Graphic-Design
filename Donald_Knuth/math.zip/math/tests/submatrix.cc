#include <iostream.h>
#include <math/math.h>
#include <math/fstream.h>

#include "print.h"

int main(void)
{
    try
    {
	math::matrix<double> A;
	math::ifstream file("matrices.mat");

	file>>A;
	print(A);

	A.subm(1,2,1,2)=A.subm(2,3,2,3);
	cout << "A(1:2,1:2)=A(2:3,2:3)\n";
	print(A);
    }
    catch(math::error::generic e)
    {
    }
}
