#include<iostream.h>
#include<math/math.h>

void print(const math::matrix<double>& A)
{
    cout << "Matrix (" << A.rows() << ',' << A.cols() << ") =\n";
    for(math::index i=1;i<=A.rows();i++)
    {
        for(math::index j=1;j<=A.cols();j++)
            cout << A(i,j) << '\t';
        cout << endl;
    }
}

int main(void)
{
    math::matrix<double> A(3,4);

    A.set(1,1,1);
    A.set(2,2,.5);
    
    cout << "Original: \n"; print(A);

    math::matrix<double> B=A;
    
    cout << "Assignment: B=A\n"; print(B);

    A.entry(1,1)=2.3; A.entry(2,2)=4.5;
    cout << "After some assignments: A\n"; print(A);
    cout << "B\n"; print(B);

    A.entry(3,3)=A(1,1)+A(2,2);
    A.entry(1,2)=A(1,1)-A(2,2)*A(3,3);
    cout << "After some algebraic assignments: "; print(A);

    return 0;
}

    
