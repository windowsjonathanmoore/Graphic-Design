#include <iostream>
#include <math/functional/quadratic.h>
#include <math/searchdir/newton.h>
#include <math/searchdir/equality.h>
#include <math/linesearch/backtracking.h>
#include <math/fmin.h>

#include "print.h"

int main(void)
{
    try
    {
	math::matrix<double> A(2,3);
	A.entry(1,1)=9;
	A.entry(1,2)=6;
	A.entry(1,3)=8;
	A.entry(2,1)=2;
	A.entry(2,2)=4;
	A.entry(2,3)=7;
	cout << "A="; print(A);

        math::matrix<double,math::symmetric> P(3,3);
        math::matrix<double> p(3,1);	
	P.entry(1,1)=2;	P.entry(1,2)=3;	P.entry(2,2)=7;
	P.entry(1,3)=1; P.entry(2,3)=1; P.entry(3,3)=1;
	p.entry(1)=-2; p.entry(2)=-8; p.entry(3)=0;

	cout << "P="; print(P);
	cout << "p="; print(p);
	cout << "pi=10" << endl << endl;
	
	math::functional::quadratic<double,math::dense> f(P,p,10);
	math::searchdir::newton<double,math::dense> basic;
	math::searchdir::equality<double,math::unstructured,math::dense> dir(&basic);
	dir.set_A(A);

        math::matrix<double> x(3,1);
        x.entry(1)=-1;
        x.entry(2)=5; /* Ax= [ 21 ; 18 ] */
	cout << "x0: "; print(x);
	cout << "f(x0)=" << f.eval(x) << endl << endl;

	math::linesearch::backtracking<double> line;
	print(math::fmin(&f,x,&line,&dir));
	cout << "f(xopt)=" << f.eval(x) << endl << endl;

    }
    catch(math::error::generic e)
    {
	cout << endl << e.message() << endl;
    }
}
