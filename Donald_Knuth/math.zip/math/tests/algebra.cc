#include <iostream.h>
#include <math/math.h>
#include <math/algebra.h>
#include <math/fstream.h>
#include <stdlib.h>

#include "print.h"

main()
{
    try
    {
        math::matrix<double> A,b1,b2;
        math::ifstream file("matrices.mat");
        
        file >> A;
        file >> A >> b1 >> A >> b2;
        
        print(A); print(b1); print(b2);
        
        A*=.5;
        cout << "A *= .5\n"; print(A);
        
        b1+=b2;
        cout << "b1 += b2\n"; print(b1);
        
        b2=saxpy(-0.9,b1,b2);
        cout << "b2 = -0.9b1+b2\n"; print(b2);
        
        gaxpy(A,b2,b1);
        cout << "b1 = A*b2+b1\n"; print(b1);
    }
    catch(math::error::generic e)
    {
        cout << e.message() << endl;
    }
}
