#include <iostream.h>
#include <math/lu.h>
#include <math/fstream.h>
#include <stdlib.h>

#include "print.h"

main()
{
    /* The MATH LU is already tested, now the tests will perform with LAPACK */
    try
    {
        math::matrix<double> A,b;
        math::ifstream file("matrices.mat");
        vector<math::index> pivots(3);
        
        file >> A;
        print(A);
        cout << endl << "LU decomposition" << endl << endl;
        math::lu::decompose(A,pivots);
        print(A); print(pivots);

        file >> A >> b;
        cout << endl << endl << "Ax=b" << endl << endl;
        print(A); print(b);
        math::lu::solve(A,b);
        print(b);
    }
    catch(math::error::generic e)
    {
        cout << e.message() << endl;
    }
}
