#include <iostream.h>
#include <math/symmetric.h>
#include <math/sparse.h>

#include "print.h"

main()
{
    math::matrix<double,math::symmetric,math::sparse> A(10,10);
    print(A);

    A.entry(1,10)=1;
    A.entry(10,1)=2;
    print(A);

    for(math::index i=1;i<=10;i++)
        for(math::index j=i;j<=10;j++)
            A.entry(i,j)=(20-i)*(i-1)/2+j;
    print(A);
}
