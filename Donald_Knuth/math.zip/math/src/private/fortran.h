#ifndef __MATH_FORTRAN__
#define __MATH_FORTRAN__ 1.0

#undef LAPACK
#undef UNDERSCORE

#ifdef LAPACK

namespace fortran {

typedef float  real;
typedef double double_precision;
typedef int    logical;
typedef int    integer;
typedef char   character;

}

#ifdef UNDERSCORE
#define sgetrf sgetrf_
#define spotrf spotrf_
#define spptrf spptrf_
#define dgetrf dgetrf_
#define dpotrf dpotrf_
#define dpptrf dpptrf_
#endif

/* The LU decomposition */
extern "C" void sgetrf(int* M,int* N,float* A,int* LDA,int* IPIV,int* INFO);
extern "C" void dgetrf(int* M,int* N,double* A,int* LDA,int* IPIV,int* INFO);

/* The Cholesky decomposition, symmetric packed. */
extern "C" void spptrf(char* UPLO,int* N,float* AP,int* INFO);
extern "C" void dpptrf(char* UPLO,int* N,double* AP,int* INFO);

/* The Cholesky decomposition, full matrix. */
extern "C" void spotrf(char* UPLO,int *N,float* A,int* LDA,int* INFO);
extern "C" void dpotrf(char* UPLO,int *N,double* A,int* LDA,int* INFO);

#endif
#endif
